INSERT INTO Setores(nome_setor,localizacao_setor,) VALUES
()