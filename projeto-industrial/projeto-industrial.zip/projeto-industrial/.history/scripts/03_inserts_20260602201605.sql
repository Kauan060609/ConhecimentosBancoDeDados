INSERT INTO Setores(nome_setor,localizacao_setor) VALUES
('Eletrônica', 'Jaraguá do Sul'),
('Automação', 'Brasil'),
('Mecânica', 'França'),
('TI', 'Portugal'),
('Ferramentaria', 'Suiça');

INSERT INTO Funcionarios(nome_funcionario,cpf_funcionario,cargo_funcionario,salario_funcionario,data_adimissao) VALUES
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('João', '123','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05');




