CREATE TABLE Setores(
nome VARCHAR(100),
localizacao VARCHAR(100)
);