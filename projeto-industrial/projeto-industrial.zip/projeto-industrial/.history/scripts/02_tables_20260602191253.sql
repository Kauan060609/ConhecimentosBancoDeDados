CREATE TABLE Setores(
id_setor INT PRIMARY KEY AUTO INCREMENT,
nome VARCHAR(100),
localizacao
);