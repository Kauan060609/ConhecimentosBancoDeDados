USE industria_db;

CREATE TABLE Setores(
id_setor INT PRIMARY KEY AUTO INCREMENT,

);