CREATE TABLE Setores(
id_setor INT PRIMARY KEY AUTO_INCREMENT,
nome_setor VARCHAR(100),
localizacao_setor VARCHAR(100)
);

DROP TABLE Setores;

CREATE TABLE Funcionarios(
id_funcionario INT PRIMARY KEY AUTO_INCREMENT,
nome_funcionario VARCHAR(100),
cpf_funcionario CHAR(11),
cargo_funcionario VARCHAR(50),
salario_funcionario INT,
data_adimissao DATE
);

CREATE TABLE Produtos(
id_produto INT PRIMARY KEY AUTO_INCREMENT,
codigo_produto INT UNIQUE,
descricao_produto TEXT,
preco_fabricacao INT,
quantidade_produto INT,
categoria_produto VARCHAR(100) NOT NULL
);

CREATE TABLE Fornecedores(
id_fornecedor INT PRIMARY KEY AUTO_INCREMENT,
razao VARCHAR(100),
cnpj_fornecedor
);