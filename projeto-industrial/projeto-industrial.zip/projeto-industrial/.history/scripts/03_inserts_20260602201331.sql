INSERT INTO Setores(nome_setor,localizacao_setor) VALUES
('Eletrônica', 'Jaraguá do Sul'),
('Automação', 'Brasil'),
('Mecânica', 'França'),
('TI', 'Portugal'),
('Ferramentaria', 'Suiça');

INSERT INTO Funcionarios(nome_funcionario,cpf_funcionario,) VALUES
('Eletrônica', 'Jaraguá do Sul'),
('Automação', 'Brasil'),
('Mecânica', 'França'),
('TI', 'Portugal'),
('Ferramentaria', 'Suiça');




