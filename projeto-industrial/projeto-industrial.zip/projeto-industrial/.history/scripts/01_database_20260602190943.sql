USE industria_db;

CREATE TABLE SETORES()