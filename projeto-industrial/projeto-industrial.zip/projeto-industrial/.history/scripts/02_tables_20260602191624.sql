CREATE TABLE Setores(
id_setor INT PRIMARY KEY,
nome VARCHAR(100),
localizacao VARCHAR(100)
);