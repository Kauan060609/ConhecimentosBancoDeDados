INSERT INTO Setores(nome_setor,localizacao_setor,id_funcionario) VALUES
()