USE industria_db;

CREATE TABLE Setores(
    
);