INSERT INTO Setores(nome_setor,localizacao_setor) VALUES
('Eletrônica', 'Jaraguá do Sul'),
('Automação', 'Brasil'),
('Mecânica', 'França'),
('TI', 'Portugal'),
('Ferramentaria', 'Suiça');

INSERT INTO Funcionarios(nome_funcionario,cpf_funcionario,cargo_funcionario,salario_funcionario,data_adimissao) VALUES
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('João', '12376545676','Pedreiro',2500,'2022-11-03'),
('Maria', '24257628310','Confeiteira',1100,'2022-11-04'),
('Paulo', '23509878920','Faxineiro',3000,'2024-12-15'),
('Vitor', '1230945620','Jardineiro',1500,'2021-11-09'),
('Junior', '45623445610','Banqueiro',4000,'2025-10-05'),
('Yago', '45687623411','Caixa',100,'2020-04-25'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05'),
('Kauan', '12345678910','Eletricista',1500,'2025-10-05');




