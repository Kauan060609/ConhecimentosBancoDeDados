INSERT INTO Setores(nome_setor,) VALUES
()