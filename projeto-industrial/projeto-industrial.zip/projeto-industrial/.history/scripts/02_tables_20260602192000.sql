CREATE TABLE Setores(
id_setor INT PRIMARY KEY AUTO INCREMENT,
nome VARCHAR(100),
localizacao VARCHAR(100)
);

DROP TABLE Setores;

CREATE TABLE Funcionarios(
id_funcionario INT PRIMARY KEY AUTO INCREMENT,
nome VARCHAR(100),
cpf CHAR(11),
cargo VARCHAR(50),
salario INT,
data_adimissao DATE
);