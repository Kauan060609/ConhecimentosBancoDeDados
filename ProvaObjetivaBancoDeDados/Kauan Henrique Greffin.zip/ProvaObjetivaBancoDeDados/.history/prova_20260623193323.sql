USE controle_ponto_db;

SHOW TABLES

-- Quest 20
SELECT * 
FROM funcionarios

-- Quest 21
SELECT mAX(salario_funcionario)
FROM funcionarios