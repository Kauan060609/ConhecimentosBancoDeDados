USE controle_ponto_db;

SHOW 