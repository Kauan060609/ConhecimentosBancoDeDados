USE controle_ponto_db;

SHOW TABLES

-- Quest 20
SELECT * 
FROM funcionarios

-- Quest 21
SELECT nome_funcionario 
FROM funcionarios
WHERE salario_funcionario =
(SELECT MAX(salario_funcionario)
 FROM funcionarios)