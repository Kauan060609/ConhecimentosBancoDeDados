USE controle_ponto_db;

SHOW TABLES

-- Quest 20
SELECT * 
