USE controle_ponto_db;

SHOW TABLES

-- Quest 20
SELECT * 
FROM funcionarios

-- Quest 21
SELECT nome_funcionari