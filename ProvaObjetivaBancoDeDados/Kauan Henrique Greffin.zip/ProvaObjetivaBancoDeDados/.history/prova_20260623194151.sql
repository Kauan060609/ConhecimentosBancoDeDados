USE controle_ponto_db;

SHOW TABLES

-- Quest 20
SELECT * 
FROM funcionarios

-- Quest 21
SELECT nome_funcionario 
FROM funcionarios
WHERE salario_funcionario =
(SELECT MAX(salario_funcionario)
 FROM funcionarios)

-- Quest 22
SELECT salario_funcionario 
FROM funcionarios
WHERE salario_funcionario =
(SELECT MIN(salario_funcionario)
 FROM funcionarios)

-- Quest 23
SELECT nome_funcionario
FROM funcionarios
WHERE data_admissao_funcionario > 01-01-2022