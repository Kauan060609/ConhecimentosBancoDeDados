USE controle_ponto_db;

SHOW TABLES

-- Quest 20
SELECT * 
FROM funcionarios

-- Quest 21
SELECT nome_funcionario 
FROM funcionarios
WHERE salario_funcionario =
(SELECT MAX(salario_funcionario)
 FROM funcionarios)

-- Quest 22
SELECT salario_funcionario 
FROM funcionarios
WHERE salario_funcionario =
(SELECT MIN(salario_funcionario)
 FROM funcionarios)

-- Quest 23
SELECT nome_funcionario
FROM funcionarios
WHERE data_admissao_funcionario > "2022-01-01"

-- Quest 24
SELECT AVG(salario_funcionario)
FROM funcionarios

-- Quest 25
SELECT nome_funcionario
FROM funcionarios
WHERE salario_funcionario > 5000

-- QUEST 26
SELECT D.nome_departamento, COUNT(id_departamento)
FROM funcionarios AS F
JOIN departamentos AS D ON D.id_departamento = F.id_departamento

